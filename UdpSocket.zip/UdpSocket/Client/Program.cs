﻿using System;
using System.Net; 
using System.Net.Sockets; 
using System.Text; 
namespace Client
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            Console.Title = "Udp Client";
            Console.Write("Server IP address: ");
            var serverIpStr = Console.ReadLine();
            var serverIp = IPAddress.Parse(serverIpStr);
            Console.Write("Server port: ");
            var serverPortStr = Console.ReadLine();
            var serverPort = int.Parse(serverPortStr);
            var serverEndpoint = new IPEndPoint(serverIp, serverPort);
            var size = 1024; 
            var receiveBuffer = new byte[size];      
            while (true)
            {
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("#Command & Text follow the syntax:\nUPPER Text\nLOWER Text\nLENGS Text\n >>> ");
                Console.ResetColor();
                var text = Console.ReadLine();
                var socket = new Socket(SocketType.Dgram, ProtocolType.Udp);
                var sendBuffer = Encoding.ASCII.GetBytes(text);
                socket.SendTo(sendBuffer, serverEndpoint);
                var length = socket.Receive(receiveBuffer);
                var result = Encoding.ASCII.GetString(receiveBuffer, 0, length);
                Array.Clear(receiveBuffer, 0, size);
                socket.Close();
                Console.WriteLine($">>> {result}");
            }
        }
    }
}