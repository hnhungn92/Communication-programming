﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Runtime.Intrinsics.X86;
using System.Text;
namespace Server
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            Console.Title = "Udp Server";
            var localIp = IPAddress.Any;
            var localPort = 1308;
            var localEndPoint = new IPEndPoint(localIp, localPort);
            var socket = new Socket(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.Udp);
            socket.Bind(localEndPoint);
            Console.WriteLine($"Local socket bind to {localEndPoint}. Waiting for request ...");
            var size = 1024;
            var receiveBuffer = new byte[size];
            while (true)
            {
                EndPoint remoteEndpoint = new IPEndPoint(IPAddress.Any, 0);
                var length = socket.ReceiveFrom(receiveBuffer, ref remoteEndpoint);
                var text = Encoding.ASCII.GetString(receiveBuffer, 0, length);
                Console.WriteLine($"Received from {remoteEndpoint}: {text}");

                string upper = "UPPER";
                string lower = "LOWER";
                string lengs = "LENGS";
                string command = text.Substring(0, 5);
                Console.WriteLine($"Command from client is: {command}");
                var result = "";

                if (String.Compare(command, upper, false)==0){
                    result = text.ToUpper();
                }
                else 
                {
                    if(String.Compare(command, lower, false) == 0) {
                        result = text.ToLower();
                    }
                    else
                    {
                        if (String.Compare(command, lengs, false) == 0)
                        {
                            int x = (text.Length) - 5;
                            result = x.ToString();
                        }
                        else{
                            result = "ERROR!";

                        }
                    }
                    
                }
                
                var sendBuffer = Encoding.ASCII.GetBytes(result);
                socket.SendTo(sendBuffer, remoteEndpoint);
                Array.Clear(receiveBuffer, 0, size);

            }
        }
    }
}