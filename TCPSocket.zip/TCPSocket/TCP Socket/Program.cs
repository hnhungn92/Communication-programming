﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Text;
namespace Server
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            Console.Title = "TCP Server";
            var localIp = IPAddress.Any;
            var localPort = 1308;
            var localEndPoint = new IPEndPoint(localIp, localPort);
            var listener = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            listener.Bind(localEndPoint);
            listener.Listen(10);
            Console.WriteLine($"Local socket bind to {localEndPoint}. Waiting for request ...");
            var size = 1024;
            var receiveBuffer = new byte[size];
            while (true)
            {
                var socket = listener.Accept();
                Console.WriteLine($"Accepted connection from {socket.RemoteEndPoint}");
                var length = socket.Receive(receiveBuffer);
                socket.Shutdown(SocketShutdown.Receive);

                var text = Encoding.ASCII.GetString(receiveBuffer, 0, length);
                Console.WriteLine($"Received: {text}");

                string result = "";
                text = text.Trim();
                while (text.IndexOf("  ") != -1)
                {
                    text = text.Replace("  ", " ");
                }
                string[] subText = text.Split(' ');

               
                for (int i = 0; i < subText.Length; i++)
                {
                    string FirstChar = subText[i].Substring(0, 1);
                    string OtherChar = subText[i].Substring(1);
                    subText[i] = FirstChar.ToUpper() + OtherChar.ToLower();
                    result += subText[i] + " ";
                }

                var sendBuffer = Encoding.ASCII.GetBytes(result);
                socket.Send(sendBuffer);
                Console.WriteLine($"Sent:{result}");
                socket.Shutdown(SocketShutdown.Send);
                Console.WriteLine($"Closing connection from {socket.RemoteEndPoint}");
                socket.Close();
                Array.Clear(receiveBuffer, 0, size);
            }
        }
    }
}